package NeuralNetworkControllers;

import com.fossgalaxy.games.fireworks.ai.Agent;
import com.fossgalaxy.games.fireworks.state.GameState;
import com.fossgalaxy.games.fireworks.state.actions.Action;

public class GeneralNeuralNetworkAgent implements Agent {
	
	private double[] features;
	private double[] activationNodes;
	
	public GeneralNeuralNetworkAgent() {
		
	}

	@Override
	public Action doMove(int agentID, GameState state) {
		// TODO Auto-generated method stub
		return null;
	}

}
